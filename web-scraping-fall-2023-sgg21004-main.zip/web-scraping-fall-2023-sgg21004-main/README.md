[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/dp82UJuw)
# STAT4185WebScrapingFall2023

Hey All!

For this week, we will be undertaking a web scraping assignment where you will scrape company stock data. While this assignment may seem challenging, please keep the following in mind:

1) You are always free to explain your approach to the question to receive full credit (refer to the syllabus for more details).
2) At the beginning of the assignment, there is a link to a cheatsheet that you're welcome to use.

Message on Discord if you have any questions!

Best,
Hari
